from node import Node

class Pilha():
    
    def __init__(self):
        """Cria a pilha vazia"""
        self.topo = None

    def esta_vazia(self):
        return not self.topo

    def push(self,dado):
        novo = Node(dado)
        novo.prox = self.topo
        self.topo = novo

    def pop(self):
        if not self.esta_vazia():
            aux = self.topo
            self.topo = self.topo.prox
            dado = aux.item
            del aux
            return dado

    def top(self):
        if not self.esta_vazia():
            return self.topo.item

    def destruir(self):
        while not self.esta_vazia():
            self.pop()

    def imprimir(self):
        aux = Pilha()
        while not self.esta_vazia():
            print(self.top())
            aux.push(self.pop())

        while not aux.esta_vazia():
            self.push(aux.pop())

    def buscar(self, info):
        aux = Pilha()
        encontrado = False

        while not self.esta_vazia():
            dado = self.pop()
            aux.push(dado)

            if dado == info:
                encontrado = True

        while not aux.esta_vazia():
            self.push(aux.pop())

        return encontrado

    def editar(self, info):
        aux = Pilha()
        editado = False

        while not self.esta_vazia():
            dado = self.pop()

            if dado == info:
                novo = input("Digite o novo valor: ")
                aux.push(novo)
                editado = True
            else:
                aux.push(dado)

        while not aux.esta_vazia():
            self.push(aux.pop())

        return editado

    def remover(self, info):
        aux = Pilha()
        removido = False

        while not self.esta_vazia():
            dado = self.pop()

            if dado == info and not removido:
                removido = True
            else:
                aux.push(dado)

        while not aux.esta_vazia():
            self.push(aux.pop())

        return removido

    def remover_repetidos(self):
        aux = Pilha()
        vistos = []

        while not self.esta_vazia():
            dado = self.pop()

            if dado not in vistos:
                vistos.append(dado)
                aux.push(dado)

        while not aux.esta_vazia():
            self.push(aux.pop())
    


