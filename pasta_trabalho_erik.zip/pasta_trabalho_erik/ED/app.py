from lista import Lista

lst = Lista()

for x in range(1, 6):
    lst.inserir_inicio(input("Elemento: "))


lst.imprimir_lista()