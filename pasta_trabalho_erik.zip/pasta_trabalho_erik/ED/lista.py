from node import Node

class Lista():
    """
    implementação de lista simplesmente encadeada
    """
    def __init__(self):
        #cria lista vazia
        self.cabeca = None

    def esta_vazia(self):
        if self.cabeca:
            return False
        else:
            return True

    def inserir_inicio(self,dado:any):
        novo = Node(dado)
        novo.prox = self.cabeca
        self.cabeca = novo


    def imprimir_lista(self):
        aux = self.cabeca
        while(aux):
            print(f">>\n{str(aux)}\n",end="")
            aux = aux.prox
        print("<<")

    def __str__(self):
        aux = self.cabeca
        txt = ""
        while(aux):
            txt = txt + f">>\n{str(aux)}\n"
            aux = aux.prox
        txt = txt + "<<"
        return txt

    def remover_inicio(self):
        if not self.esta_vazia():
            aux = self.cabeca
            self.cabeca = self.cabeca.prox
            del aux

    def inserir_final(self,dado):
        novo = Node(dado)
        #chegar ao final da lista
        if not self.esta_vazia():
            aux = self.cabeca
            #percorrer lista até o ultimo elemento
            while(aux.prox):
                aux = aux.prox
            aux.prox = novo
        else:
            novo.prox = self.cabeca
            self.cabeca = novo

    def remover_final(self):
        if not self.esta_vazia():
            aux = self.cabeca
            ant = None
            #percorrer até o ultimo elemento
            while(aux.prox):
                ant = aux
                aux = aux.prox
            if aux != self.cabeca:
                ant.prox = None
            else:
                self.cabeca = None
            del aux

    def inserir_ordenado(self,dado):
        novo = Node(dado)
        if not self.esta_vazia():
            aux = self.cabeca
            ant = None
            if dado > self.cabeca.item:
                #percorre até achar o ponto de inserção
                while aux and dado > aux.item:
                    ant = aux
                    aux = aux.prox
                ant.prox = novo
                novo.prox = aux
            else:
                novo.prox = self.cabeca
                self.cabeca = novo
        else:
            self.cabeca = novo

    def remover_dado(self,dado_busca):
        if (not self.esta_vazia()):
            ant = None
            aux = self.cabeca
        while (aux and dado_busca != aux.item):
            ant = aux
            aux = aux.prox
        if aux:
            if aux != self.cabeca:
                ant.prox = aux.prox
        else:
            self.cabeca = self.cabeca.prox
        del aux

    def mostra_menor(self):
        aux = self.cabeca
        menor = aux.item
        while aux:
            if aux.item < menor:
                menor = aux.item
            aux = aux.prox
        print(f"\n[{menor}]")
        return menor

    def mostra_maior(self):
        aux = self.cabeca
        maior = aux.item
        while aux:
            if aux.item > maior:
                maior = aux.item
            aux = aux.prox
        print(f"\n[{maior}]")
        return maior

    def mostrar_soma(self):
        aux = self.cabeca
        somador = 0

        while aux:
            somador += int(aux.item)
            aux = aux.prox

        print(f"\n[{somador}]")
        return somador

    def mostrar_quantidade(self):
        aux = self.cabeca
        con = 0
        while aux:
            con += 1
            aux = aux.prox
        print(f"\n[{con}]")
        return con

    def mostrar_media(self):
        aux = self.cabeca
        somador = 0
        con = 0

        while aux:
            somador += int(aux.item)
            aux = aux.prox
            con += 1
        media = somador / con

        print(f"\n[{media:.2f}]")
        return media

    def conectar_lista(self, outra_lista):
        if outra_lista.cabeca is None:
            return

        if self.cabeca is None:
            self.cabeca = outra_lista.cabeca
            return

        aux = self.cabeca

        while aux.prox:
            aux = aux.prox

        aux.prox = outra_lista.cabeca
        return

    def mostrar_anterior(self):
        anterior = None
        atual = self.cabeca

        while atual:
            proximo = atual.prox
            atual.prox = anterior
            anterior = atual
            atual = proximo

        self.cabeca = anterior
        return